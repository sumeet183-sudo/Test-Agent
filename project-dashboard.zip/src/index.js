import React from 'react';
import { createRoot } from 'react-dom/client';
import ProjectDashboard from './ProjectDashboard';
import './index.css';

function App(){
  return <ProjectDashboard />;
}

const container = document.getElementById('root');
const root = createRoot(container);
root.render(<App />);
