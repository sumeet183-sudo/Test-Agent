import React, { useEffect, useMemo, useState } from "react";

// Single-file React component for a modern Project Management Dashboard
// Uses Tailwind classes for styling (Tailwind should be available in the host app).
// Uses recharts and framer-motion (both available per instructions). Replace or remove if not installed.

import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";
import { motion } from "framer-motion";

// ---------- Mock data helpers ----------
const sampleProjects = [
  {
    id: "p-1",
    name: "Website Redesign",
    description: "Landing page + marketing site overhaul",
    startDate: "2025-09-01",
    endDate: "2025-11-30",
    priority: "High",
    status: "In Progress",
    team: ["Sam", "Aisha", "Rohit"],
    tags: ["Marketing", "Frontend"],
    progress: 45,
    tasks: [
      { id: "t-1", title: "Wireframes", status: "Done", assignee: "Sam", due: "2025-09-10" },
      { id: "t-2", title: "Prototype", status: "In Progress", assignee: "Aisha", due: "2025-09-25" },
      { id: "t-3", title: "Implement", status: "To Do", assignee: "Rohit", due: "2025-10-15" }
    ]
  },
  {
    id: "p-2",
    name: "Mobile App MVP",
    description: "Deliver first version to closed beta users",
    startDate: "2025-07-10",
    endDate: "2025-10-01",
    priority: "Medium",
    status: "On Hold",
    team: ["Maya", "Sam"],
    tags: ["Mobile", "Backend"],
    progress: 20,
    tasks: []
  }
];

const PRIORITY_COLOR = {
  High: "bg-red-500",
  Medium: "bg-yellow-400",
  Low: "bg-green-400"
};

const STATUS_COLORS = {
  "Not Started": "text-gray-500",
  "In Progress": "text-blue-500",
  "On Hold": "text-orange-500",
  Completed: "text-green-500"
};

function uid(prefix = "id") {
  return `${prefix}-${Math.random().toString(36).slice(2, 9)}`;
}

function parseCSVtoProjects(text) {
  const lines = text.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
  if (lines.length === 0) return [];
  const header = lines.shift().split(",").map(h => h.trim());
  const rows = lines.map(line => {
    const parts = line.split(",").map(p => p.trim());
    const obj = {};
    header.forEach((h, i) => (obj[h] = parts[i] ?? ""));
    return obj;
  });

  return rows.map(r => ({
    id: uid("imp"),
    name: r["Name"] || r["Project Name"] || "Imported Project",
    description: r["Description"] || "",
    startDate: r["Start Date"] || "",
    endDate: r["End Date"] || "",
    priority: r["Priority"] || "Low",
    status: r["Status"] || "Not Started",
    team: r["Team"] ? r["Team"].split(";").map(s => s.trim()) : [],
    tags: r["Tags"] ? r["Tags"].split(";").map(s => s.trim()) : [],
    progress: Number(r["Progress"] || 0),
    tasks: []
  }));
}

export default function ProjectDashboard() {
  const [projects, setProjects] = useState(() => sampleProjects);
  const [selectedProjectId, setSelectedProjectId] = useState(projects[0]?.id || null);
  const [q, setQ] = useState("");
  const [filterStatus, setFilterStatus] = useState("All");
  const [filterPriority, setFilterPriority] = useState("All");
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [editingProject, setEditingProject] = useState(null);
  const [notifications, setNotifications] = useState([]);
  const [darkMode, setDarkMode] = useState(false);

  const selectedProject = useMemo(() => projects.find(p => p.id === selectedProjectId) ?? null, [projects, selectedProjectId]);

  const filteredProjects = useMemo(() => {
    return projects.filter(p => {
      if (filterStatus !== "All" && p.status !== filterStatus) return false;
      if (filterPriority !== "All" && p.priority !== filterPriority) return false;
      if (q) {
        const term = q.toLowerCase();
        return p.name.toLowerCase().includes(term) || p.description.toLowerCase().includes(term) || p.tags.join(",").toLowerCase().includes(term);
      }
      return true;
    });
  }, [projects, filterStatus, filterPriority, q]);

  useEffect(() => {
    if (filteredProjects.length && !filteredProjects.find(p => p.id === selectedProjectId)) {
      setSelectedProjectId(filteredProjects[0].id);
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filterStatus, filterPriority, q]);

  function createProject(data) {
    const newProject = {
      id: uid("p"),
      name: data.name || "New Project",
      description: data.description || "",
      startDate: data.startDate || new Date().toISOString().slice(0,10),
      endDate: data.endDate || new Date().toISOString().slice(0,10),
      priority: data.priority || "Low",
      status: data.status || "Not Started",
      team: data.team || [],
      tags: data.tags || [],
      progress: 0,
      tasks: []
    };
    setProjects(prev => [newProject, ...prev]);
    setNotifications(n => [{ id: uid("n"), message: `Project '${newProject.name}' created`, time: Date.now() }, ...n]);
    setShowCreateModal(false);
    setSelectedProjectId(newProject.id);
  }

  function modifyProject(id, patch) {
    setProjects(prev => prev.map(p => p.id === id ? { ...p, ...patch } : p));
    setNotifications(n => [{ id: uid("n"), message: `Project updated`, time: Date.now() }, ...n]);
  }

  function deleteProject(id) {
    if (!confirm("Are you sure you want to delete this project? This action cannot be undone.")) return;
    setProjects(prev => prev.filter(p => p.id !== id));
    setNotifications(n => [{ id: uid("n"), message: `Project deleted`, time: Date.now() }, ...n]);
    setSelectedProjectId(prev => {
      if (prev === id) return projects[0]?.id ?? null;
      return prev;
    });
  }

  function addTask(projectId, task) {
    setProjects(prev => prev.map(p => p.id === projectId ? { ...p, tasks: [...p.tasks, { id: uid("t"), ...task }] } : p));
  }

  function updateTask(projectId, taskId, patch) {
    setProjects(prev => prev.map(p => p.id === projectId ? { ...p, tasks: p.tasks.map(t => t.id === taskId ? { ...t, ...patch } : t) } : p));
  }

  function removeTask(projectId, taskId) {
    setProjects(prev => prev.map(p => p.id === projectId ? { ...p, tasks: p.tasks.filter(t => t.id !== taskId) } : p));
  }

  function handleFileImport(file) {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (e) => {
      const text = e.target.result;
      try {
        const imported = parseCSVtoProjects(text);
        setProjects(prev => [...imported, ...prev]);
        setNotifications(n => [{ id: uid("n"), message: `Imported ${imported.length} projects from file.`, time: Date.now() }, ...n]);
      } catch (err) {
        alert("Failed to parse file. Make sure it is CSV with the right columns.");
      }
    };
    reader.readAsText(file);
  }

  const metrics = useMemo(() => {
    const total = projects.length;
    const completed = projects.filter(p => p.status === "Completed").length;
    const inProgress = projects.filter(p => p.status === "In Progress").length;
    const overdue = projects.filter(p => new Date(p.endDate) < new Date() && p.status !== "Completed").length;
    return { total, completed, inProgress, overdue };
  }, [projects]);

  const pieData = useMemo(() => {
    const groups = { "Not Started": 0, "In Progress": 0, "On Hold": 0, Completed: 0 };
    projects.forEach(p => groups[p.status] = (groups[p.status] || 0) + 1);
    return Object.keys(groups).map(key => ({ name: key, value: groups[key] }));
  }, [projects]);

  const COLORS = ["#4F46E5","#0EA5E9","#F59E0B","#10B981"];

  function ProjectCard({ project, onSelect }) {
    return (
      <motion.div layout whileHover={{ scale: 1.01 }} className="p-3 bg-white dark:bg-slate-800 rounded-2xl shadow-sm border">
        <div className="flex justify-between items-start gap-2">
          <div className="flex-1">
            <div className="flex items-center gap-2">
              <h3 className="font-semibold text-sm">{project.name}</h3>
              <span className={`text-xs ${STATUS_COLORS[project.status] || 'text-gray-600'}`}>{project.status}</span>
            </div>
            <p className="text-xs text-gray-500 dark:text-gray-300 mt-1 truncate">{project.description}</p>
          </div>
          <div className="text-right">
            <div className={`inline-block rounded-full px-2 py-0.5 text-xs ${PRIORITY_COLOR[project.priority] || 'bg-gray-200'}`}>{project.priority}</div>
          </div>
        </div>

        <div className="mt-3">
          <div className="w-full bg-gray-100 rounded-full h-2 overflow-hidden">
            <div className="h-2 rounded-full" style={{ width: `${project.progress}%`, background: `linear-gradient(90deg,#4F46E5,#06B6D4)` }} />
          </div>
          <div className="flex justify-between items-center mt-2 text-xs text-gray-500">
            <div>{project.tasks.length} tasks</div>
            <div>Due: {project.endDate}</div>
          </div>
        </div>

        <div className="mt-3 flex items-center gap-2">
          {project.team.slice(0,4).map((m, i) => (
            <div key={i} className="w-7 h-7 rounded-full bg-gray-200 dark:bg-slate-700 flex items-center justify-center text-xs">{m[0]}</div>
          ))}
          <div className="ml-auto flex gap-2">
            <button onClick={() => { setEditingProject(project); setShowCreateModal(true); }} className="text-xs px-2 py-1 rounded hover:bg-slate-100">Edit</button>
            <button onClick={() => deleteProject(project.id)} className="text-xs px-2 py-1 rounded text-red-500 hover:bg-red-50">Delete</button>
            <button onClick={() => onSelect(project.id)} className="text-xs px-2 py-1 rounded bg-blue-50">Open</button>
          </div>
        </div>
      </motion.div>
    );
  }

  function CreateEditModal({ open, onClose, project }) {
    const isEdit = !!project;
    const [form, setForm] = useState(project || { name: "", description: "", startDate: "", endDate: "", priority: "Low", status: "Not Started", team: [], tags: [] });

    useEffect(() => { setForm(project || { name: "", description: "", startDate: "", endDate: "", priority: "Low", status: "Not Started", team: [], tags: [] }); }, [project]);

    function submit() {
      if (!form.name) return alert("Project name required");
      if (isEdit) modifyProject(project.id, form);
      else createProject(form);
      onClose();
    }

    return open ? (
      <div className="fixed inset-0 z-40 flex items-center justify-center p-4">
        <div onClick={onClose} className="absolute inset-0 bg-black/30" />
        <motion.div initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} className="relative z-50 w-full max-w-2xl bg-white dark:bg-slate-900 rounded-xl p-6 shadow-2xl">
          <h3 className="text-lg font-semibold">{isEdit ? 'Edit Project' : 'Create Project'}</h3>
          <div className="mt-4 grid grid-cols-2 gap-3">
            <input value={form.name} onChange={(e)=>setForm({...form,name:e.target.value})} placeholder="Project name" className="col-span-2 p-2 rounded border" />
            <textarea value={form.description} onChange={(e)=>setForm({...form,description:e.target.value})} placeholder="Description" className="col-span-2 p-2 rounded border" />
            <input type="date" value={form.startDate} onChange={(e)=>setForm({...form,startDate:e.target.value})} className="p-2 rounded border" />
            <input type="date" value={form.endDate} onChange={(e)=>setForm({...form,endDate:e.target.value})} className="p-2 rounded border" />
            <select value={form.priority} onChange={(e)=>setForm({...form,priority:e.target.value})} className="p-2 rounded border">
              <option>Low</option>
              <option>Medium</option>
              <option>High</option>
            </select>
            <select value={form.status} onChange={(e)=>setForm({...form,status:e.target.value})} className="p-2 rounded border">
              <option>Not Started</option>
              <option>In Progress</option>
              <option>On Hold</option>
              <option>Completed</option>
            </select>
            <input placeholder="Team members (comma separated)" value={form.team.join(", ")} onChange={(e)=>setForm({...form,team:e.target.value.split(",").map(s=>s.trim())})} className="col-span-2 p-2 rounded border" />
            <input placeholder="Tags (comma separated)" value={form.tags.join(", ")} onChange={(e)=>setForm({...form,tags:e.target.value.split(",").map(s=>s.trim())})} className="col-span-2 p-2 rounded border" />
          </div>

          <div className="mt-4 flex justify-end gap-2">
            <button onClick={onClose} className="px-4 py-2 rounded">Cancel</button>
            <button onClick={submit} className="px-4 py-2 rounded bg-blue-600 text-white">{isEdit ? 'Save' : 'Create'}</button>
          </div>
        </motion.div>
      </div>
    ) : null;
  }

  return (
    <div className={`${darkMode ? 'dark' : ''} min-h-screen bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-slate-100`}> 
      <div className="max-w-7xl mx-auto p-6">
        <header className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">Project Control Panel</h1>
            <p className="text-sm text-gray-500">A central place to manage all projects, tasks and timelines.</p>
          </div>
          <div className="flex items-center gap-3">
            <label className="flex items-center gap-2 text-sm">
              <input type="checkbox" checked={darkMode} onChange={(e)=>setDarkMode(e.target.checked)} /> Dark
            </label>
            <div className="flex items-center gap-2">
              <input value={q} onChange={(e)=>setQ(e.target.value)} placeholder="Search projects or tasks..." className="p-2 rounded border" />
              <button onClick={()=>setShowCreateModal(true)} className="px-3 py-2 bg-blue-600 text-white rounded">New Project</button>
            </div>
            <div className="relative">
              <input type="file" accept=".csv,.txt" onChange={(e)=>handleFileImport(e.target.files?.[0])} className="hidden" id="csv-in" />
              <label htmlFor="csv-in" className="px-3 py-2 bg-slate-100 rounded cursor-pointer">Import CSV</label>
            </div>
          </div>
        </header>

        <main className="mt-6 grid grid-cols-4 gap-6">
          <section className="col-span-1">
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-sm font-semibold">Projects</h2>
              <div className="text-xs text-gray-500">{projects.length} total</div>
            </div>

            <div className="grid gap-3">
              <div className="flex gap-2 mb-2">
                <select value={filterStatus} onChange={(e)=>setFilterStatus(e.target.value)} className="p-2 rounded border text-sm">
                  <option>All</option>
                  <option>Not Started</option>
                  <option>In Progress</option>
                  <option>On Hold</option>
                  <option>Completed</option>
                </select>
                <select value={filterPriority} onChange={(e)=>setFilterPriority(e.target.value)} className="p-2 rounded border text-sm">
                  <option>All</option>
                  <option>Low</option>
                  <option>Medium</option>
                  <option>High</option>
                </select>
              </div>

              <div className="space-y-3 overflow-y-auto max-h-[60vh]">
                {filteredProjects.map(p => (
                  <div key={p.id} onClick={()=>setSelectedProjectId(p.id)}>
                    <ProjectCard project={p} onSelect={(id)=>setSelectedProjectId(id)} />
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="col-span-2">
            {selectedProject ? (
              <div className="bg-white dark:bg-slate-800 rounded-2xl p-4 shadow-sm">
                <div className="flex justify-between items-start gap-4">
                  <div>
                    <h2 className="text-xl font-semibold">{selectedProject.name}</h2>
                    <p className="text-sm text-gray-500 dark:text-gray-300">{selectedProject.description}</p>
                    <div className="mt-2 flex items-center gap-3 text-sm">
                      <div>Progress: <strong>{selectedProject.progress}%</strong></div>
                      <div>Due: <strong>{selectedProject.endDate}</strong></div>
                      <div className={`px-2 rounded text-xs ${PRIORITY_COLOR[selectedProject.priority] || 'bg-gray-200'}`}>{selectedProject.priority}</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <button onClick={()=>modifyProject(selectedProject.id, { status: 'Completed', progress: 100 })} className="px-3 py-2 rounded bg-green-600 text-white text-sm">Mark Completed</button>
                    <button onClick={()=>{ setEditingProject(selectedProject); setShowCreateModal(true); }} className="px-3 py-2 rounded border">Edit</button>
                    <button onClick={()=>deleteProject(selectedProject.id)} className="px-3 py-2 rounded border text-red-600">Delete</button>
                  </div>
                </div>

                <div className="mt-4 grid grid-cols-3 gap-4">
                  <div className="col-span-2">
                    <h3 className="text-sm font-semibold mb-2">Tasks</h3>
                    <div className="space-y-2">
                      {selectedProject.tasks.map(task => (
                        <div key={task.id} className="p-3 bg-gray-50 dark:bg-slate-700 rounded flex justify-between items-center">
                          <div>
                            <div className="font-medium">{task.title}</div>
                            <div className="text-xs text-gray-500">{task.assignee} • Due {task.due}</div>
                          </div>
                          <div className="flex items-center gap-2">
                            <select value={task.status} onChange={(e)=>updateTask(selectedProject.id, task.id, { status: e.target.value })} className="p-1 rounded border text-xs">
                              <option>To Do</option>
                              <option>In Progress</option>
                              <option>Review</option>
                              <option>Done</option>
                            </select>
                            <button onClick={()=>removeTask(selectedProject.id, task.id)} className="text-xs text-red-500">Remove</button>
                          </div>
                        </div>
                      ))}

                      <AddTaskInline onAdd={(t) => addTask(selectedProject.id, t)} />
                    </div>
                  </div>

                  <div>
                    <h3 className="text-sm font-semibold mb-2">Mini Timeline</h3>
                    <div className="p-3 bg-gray-50 dark:bg-slate-700 rounded">
                      <div className="text-xs">Start: {selectedProject.startDate}</div>
                      <div className="text-xs">End: {selectedProject.endDate}</div>
                      <div className="mt-2 w-full bg-gray-200 h-2 rounded"><div style={{ width: `${selectedProject.progress}%`, height: 8, borderRadius: 8, background: '#4F46E5' }} /></div>
                    </div>

                    <h3 className="text-sm font-semibold mt-4 mb-2">Team</h3>
                    <div className="flex gap-2 flex-wrap">
                      {selectedProject.team.map((m, i) => <div key={i} className="px-3 py-1 rounded bg-slate-100 dark:bg-slate-700 text-sm">{m}</div>)}
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="p-6 bg-white dark:bg-slate-800 rounded-2xl">Select a project to view details</div>
            )}
          </section>

          <aside className="col-span-1">
            <div className="bg-white dark:bg-slate-800 rounded-2xl p-4 shadow-sm">
              <h3 className="text-sm font-semibold">Overview</h3>
              <div className="mt-3 grid gap-3">
                <div className="text-xs">Total projects: <strong>{metrics.total}</strong></div>
                <div className="text-xs">Completed: <strong>{metrics.completed}</strong></div>
                <div className="text-xs">Active: <strong>{metrics.inProgress}</strong></div>
                <div className="text-xs">Overdue: <strong>{metrics.overdue}</strong></div>

                <div style={{ width: '100%', height: 150 }}>
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie dataKey="value" data={pieData} innerRadius={30} outerRadius={50} paddingAngle={2}>
                        {pieData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </div>

                <div className="mt-2">
                  <h4 className="text-sm font-medium">Upcoming Deadlines</h4>
                  <ul className="text-xs mt-2 space-y-1">
                    {projects.sort((a,b)=>new Date(a.endDate)-new Date(b.endDate)).slice(0,5).map(p => (
                      <li key={p.id} className="flex justify-between">
                        <span>{p.name}</span>
                        <span className="text-gray-500">{p.endDate}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="mt-3">
                  <h4 className="text-sm font-medium">Burndown (mock)</h4>
                  <div style={{ width: '100%', height: 80 }}>
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={[{name:'W1',v:20},{name:'W2',v:40},{name:'W3',v:60},{name:'W4',v:40}]}> 
                        <XAxis dataKey="name" />
                        <YAxis />
                        <Tooltip />
                        <Bar dataKey="v" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-4 bg-white dark:bg-slate-800 rounded-2xl p-4 shadow-sm">
              <h3 className="text-sm font-semibold">Gantt / Timeline</h3>
              <div className="mt-3 text-xs text-gray-500">Interactive Gantt not implemented in demo — placeholder below. For production use, integrate a Gantt library (e.g., "@toast-ui/react-gantt" or "dhtmlx-gantt") to get dependencies, drag-and-drop, and resize features.</div>
              <div className="mt-3 p-3 bg-gray-50 dark:bg-slate-700 rounded">[Gantt chart placeholder — drag & drop UI recommended]</div>
            </div>
          </aside>
        </main>

        <CreateEditModal open={showCreateModal} onClose={()=>{ setShowCreateModal(false); setEditingProject(null); }} project={editingProject} />

        <div className="fixed bottom-6 right-6 w-80">
          {notifications.slice(0,4).map(n => (
            <div key={n.id} className="mb-2 p-3 rounded bg-white dark:bg-slate-800 shadow">{n.message}</div>
          ))}
        </div>
      </div>
    </div>
  );
}

function AddTaskInline({ onAdd }) {
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ title: '', assignee: '', due: '', status: 'To Do' });

  function submit() {
    if (!form.title) return alert('Task title required');
    onAdd(form);
    setForm({ title: '', assignee: '', due: '', status: 'To Do' });
    setOpen(false);
  }

  if (!open) return <button onClick={()=>setOpen(true)} className="mt-2 text-sm px-3 py-2 rounded border">+ Add task</button>;

  return (
    <div className="p-3 bg-white dark:bg-slate-800 rounded">
      <input value={form.title} onChange={(e)=>setForm({...form,title:e.target.value})} placeholder="Task title" className="w-full p-2 rounded border mb-2" />
      <input value={form.assignee} onChange={(e)=>setForm({...form,assignee:e.target.value})} placeholder="Assignee" className="w-full p-2 rounded border mb-2" />
      <input type="date" value={form.due} onChange={(e)=>setForm({...form,due:e.target.value})} className="w-full p-2 rounded border mb-2" />
      <div className="flex justify-end gap-2">
        <button onClick={()=>setOpen(false)} className="px-3 py-1 rounded">Cancel</button>
        <button onClick={submit} className="px-3 py-1 rounded bg-blue-600 text-white">Add</button>
      </div>
    </div>
  );
}
